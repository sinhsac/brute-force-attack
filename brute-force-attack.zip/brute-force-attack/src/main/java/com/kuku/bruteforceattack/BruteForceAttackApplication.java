package com.kuku.bruteforceattack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BruteForceAttackApplication {

	public static void main(String[] args) {
		SpringApplication.run(BruteForceAttackApplication.class, args);
	}

}
